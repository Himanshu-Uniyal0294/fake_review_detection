# Fake-product-Review-monitoring-system
The Fake Product Review Monitoring System uses sentiment analysis, word clouds, and classification to detect fake Amazon reviews. It preprocesses data, analyzes sentiments, and trains models like Logistic Regression. Deployed on Streamlit, it provides real-time predictions in a user-friendly interface, aiding in identifying deceptive reviews.
